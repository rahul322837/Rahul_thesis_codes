#!/usr/bin/env python
# coding: utf-8

# In[1]:


import keras
keras.__version__


# In[2]:


import os, shutil
from distutils.dir_util import copy_tree


# In[3]:


# The path to the directory where the original
# dataset was uncompressed
original_dir_failure = 'C:/frames/failure'
original_dir_success = 'C:/frames/success'

# The directory where we will
# store our smaller dataset
base_dir = 'C:/Thesis/data partition'
if not os.path.exists(base_dir):
        os.mkdir(base_dir)

# Directories for our training,
# validation and test splits 
train_dir = os.path.join(base_dir, 'train')
if not os.path.exists(train_dir):
    os.mkdir(train_dir)

validation_dir = os.path.join(base_dir, 'validation')
if not os.path.exists(validation_dir):
        os.mkdir(validation_dir)

test_dir = os.path.join(base_dir, 'test')
if not os.path.exists(test_dir):
    os.mkdir(test_dir)


# In[4]:


# Directory with our training fail shots
train_fail_dir = os.path.join(train_dir, 'failure')
if not os.path.exists(train_fail_dir):
    os.mkdir(train_fail_dir)

# Directory with our training success shots
train_success_dir = os.path.join(train_dir, 'success')
if not os.path.exists(train_success_dir):
    os.mkdir(train_success_dir)

# Directory with our validation fail shots
validation_fail_dir = os.path.join(validation_dir, 'failure')
if not os.path.exists(validation_fail_dir):
    os.mkdir(validation_fail_dir)

# Directory with our validation success shots
validation_success_dir = os.path.join(validation_dir, 'success')
if not os.path.exists(validation_success_dir):
    os.mkdir(validation_success_dir)

# Directory with our test fail shots
test_fail_dir = os.path.join(test_dir, 'failure')
if not os.path.exists(test_fail_dir):
    os.mkdir(test_fail_dir)

# Directory with our test success shots
test_success_dir = os.path.join(test_dir, 'success')
if not os.path.exists(test_success_dir):
    os.mkdir(test_success_dir)


# In[19]:


# Copy first 60 failure shots to train_fail_dir
fnames = ['{}'.format(i) for i in range(1, 61)]
for fname in fnames:
    src = os.path.join(original_dir_failure, fname)
    dest = os.path.join(train_fail_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)



# In[20]:


# Copy next 30 fail shots to validation_fail_dir
fnames = ['{}'.format(i) for i in range(61, 91)]
for fname in fnames:
    src = os.path.join(original_dir_failure, fname)
    dest = os.path.join(validation_fail_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[21]:


# Copy next 21 fail shots to test_fail_dir
fnames = ['{}'.format(i) for i in range(91, 112)]
for fname in fnames:
    src = os.path.join(original_dir_failure, fname)
    dest = os.path.join(test_fail_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[22]:


# Copy first 30 success shots to train_success_dir
fnames = ['{}'.format(i) for i in range(1, 31)]
for fname in fnames:
    src = os.path.join(original_dir_success, fname)
    dest = os.path.join(train_success_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[24]:


# Copy first 16 success shots to validation_success_dir
fnames = ['{}'.format(i) for i in range(31, 47)]
for fname in fnames:
    src = os.path.join(original_dir_success, fname)
    dest = os.path.join(validation_success_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[25]:


# Copy first 10 success shots to test_success_dir
fnames = ['{}'.format(i) for i in range(47, 57)]
for fname in fnames:
    src = os.path.join(original_dir_success, fname)
    dest = os.path.join(test_success_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[ ]:





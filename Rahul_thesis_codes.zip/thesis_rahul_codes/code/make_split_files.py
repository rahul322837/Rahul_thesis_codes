import os

train_file = open("train_file_imbalance_150200.txt", "w")
test_file = open("test_file_imbalance_150200.txt", "w")
val_file = open("val_file_imbalance_150200.txt", "w")

root = "C:\Thesis/data partition 300/"

data_split = os.listdir(root)
#print(data_split) #test/train/val

for folder in data_split:
    if folder == "train":
        class_folders = os.listdir(root + folder)  #train->failure/success
        #print(class_folders)
        
        for sub_folders in class_folders:
            frame_folders = os.listdir(root + folder + "/" + sub_folders) #train -> failure/success -> frame_folders(1...n) 
            #print(frame_folders, len(frame_folders))
            
            if sub_folders == "failure":
                for i in frame_folders:
                        train_file.write(sub_folders + "/" + i + " " + "0" + "\n")
            else:
                for i in frame_folders:
                    train_file.write(sub_folders + "/" + i + " " + "1" + "\n")
    
    elif folder == "test":
        class_folders = os.listdir(root + folder)  #test->failure/success
        #print(class_folders)
        
        for sub_folders in class_folders:
            frame_folders = os.listdir(root + folder + "/" + sub_folders) #test -> failure/success -> frame_folders(1...n) 
            #print(frame_folders, len(frame_folders))
            
            if sub_folders == "failure":
                for i in frame_folders:
                        test_file.write(sub_folders + "/" + i + " " + "0" + "\n")
            else:
                for i in frame_folders:
                    test_file.write(sub_folders + "/" + i + " " + "1" + "\n")
    else:
        class_folders = os.listdir(root + folder)  #val->failure/success
        #print(class_folders)
        
        for sub_folders in class_folders:
            frame_folders = os.listdir(root + folder + "/" + sub_folders) #val -> failure/success -> frame_folders(1...n) 
            #print(frame_folders, len(frame_folders))
            
            if sub_folders == "failure":
                for i in frame_folders:
                        val_file.write(sub_folders + "/" + i + " " + "0" + "\n")
            else:
                for i in frame_folders:
                    val_file.write(sub_folders + "/" + i + " " + "1" + "\n")
        
        